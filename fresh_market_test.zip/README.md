# Fresh Market Test — from scratch

این پروژه کاملاً مستقل و از صفر نوشته شده است و هیچ فایل پروژه قبلی در آن استفاده نشده.

## قوانین تست‌شده
- قیمت خرید تجهیزات جنگی = قیمت پایه × 7
- 🏕️ پایگاه = 10,000,000
- بمب‌های پیشرفته اصلاً ×7 نمی‌شوند:
  - Antimatter Bomb = 30M
  - Hydrogen Bomb = 14M
  - H2 Bomb = 10M
  - Chemical Bomb = 4M
  - new life = 500M
- قیمت فروش هر کالا = قیمت خرید / 1.2
- New Life فقط برای کشور کاملاً فتح‌شده طراحی شده و کشور را دوباره زنده می‌کند.
- نیروی انسانی و پایگاه داخل بخش تجهیزات جنگی هستند.

## اجرا
```bash
pip install -r requirements.txt
export BOT_TOKEN="TOKEN"
python bot.py
```

برای Deployka:
- متغیر محیطی `BOT_TOKEN` را تنظیم کن.
- در صورت نیاز `DB_PATH=/data/market_test.db` بگذار تا دیتابیس روی دیسک persistent باشد.

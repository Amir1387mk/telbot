
# Fresh standalone market/equipment test bot
# Built from scratch — no previous project files are used.

import os
import sqlite3
from pathlib import Path
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, ContextTypes
)

DB_PATH = Path(os.getenv("DB_PATH", "/tmp/market_test.db"))

# ----------------------------
# Pricing rules
# ----------------------------
WAR_MULTIPLIER = 7

RAW_PRICES = {
    "الماس خام": 5_000_000,
    "طلا خام": 4_000_000,
    "نقره خام": 3_000_000,
    "مس خام": 2_000_000,
    "آهن خام": 2_000_000,
    "چوب خام": 1_000_000,
    "نفت خام": 2_500,
    "نفت سفید": 3_500,
}

INGOT_PRICES = {
    "شمش الماس": 7_000_000,
    "شمش طلا": 6_000_000,
    "شمش نقره": 5_000_000,
    "شمش مس": 4_000_000,
    "شمش آهن": 4_000_000,
}

WAR_EQUIPMENT_BASE = {
    # Ground
    "KF51 Tank": 11_000,
    "T-14 Tank": 10_750,
    "Leopard 2 Tank": 10_250,
    "Merkava IV Tank": 10_000,
    "Black Panther Tank": 10_000,
    "Leclerc Tank": 9_500,
    "Challenger 2 Tank": 9_500,
    "Type 10 Tank": 9_500,
    "Altay Tank": 9_000,
    "T-84 Oplot Tank": 8_000,
    "VT-4 Tank": 8_000,
    "Ariete Tank": 7_000,
    "Zulfiqar Tank": 4_500,
    "Tiran-6 Tank": 4_500,
    "Chonma-216 Tank": 4_000,

    # Air defense
    "Starstreak": 45_000,
    "Rapier": 44_000,
    "Sea Wolf": 43_000,
    "Crotale": 42_000,
    "Khordad": 41_000,
    "Tor M33": 40_000,
    "MIM-23 Hawk": 39_000,
    "Ayn al-Hayat": 38_000,
    "Sayyad-2": 37_000,
    "MIG-31": 35_000,
    "Bavar 373": 33_000,
    "Dezfool": 25_000,
    "Saegheh": 21_000,
    "Kowsar": 20_000,
    "Ya Zahra": 20_000,
    "Raad": 19_000,
    "Simorgh": 17_000,
    "Azaraksh": 16_000,
    "Iron Dome": 12_000,

    # Jets
    "F-22 Raptor": 150_000,
    "Su-57 Felon": 145_000,
    "Su-35BM Flanker-E": 135_000,
    "Typhoon FGR4": 125_000,
    "J-20 Mighty Dragon": 120_000,
    "F-35 Lightning II": 120_000,
    "F-15EX Eagle II": 95_000,
    "F-15E Strike Eagle": 90_000,
    "F-2A": 89_000,
    "Su-47 Berkut Sukhoi": 85_000,
    "J-35 Gyrfalcon": 85_000,

    # Bombers
    "B-21 Raider": 450_000,
    "F-111 Aardvark": 430_000,
    "B-1B Lancer": 400_000,
    "B-52H Stratofortress": 370_000,
    "H-6": 260_000,
    "B-47": 230_000,
    "B-50": 220_000,
    "B-45 Tornado": 210_000,
    "B-29 Superfortress": 165_000,
    "B-26 Marauder": 160_000,
    "B-24 Liberator": 155_000,
    "Vickers Wellington": 150_000,
    "B-17 Flying Fortress": 150_000,

    # Missiles
    "MGM-29 Sergeant": 4_500,
    "MGM-5 Corporal": 4_500,
    "AGM-84 Harpoon": 5_600,
    "RIM-174 Standard ERAM": 5_600,
    "Fateh-313": 5_800,
    "Shahab-1": 5_800,
    "MGM-140 ATACMS": 5_800,
    "Kheibar Shekan": 9_100,
    "Emad": 9_400,
    "Sejjil": 10_000,
    "Adel": 10_000,
    "Jupiter": 11_000,
    "Polaris A3": 14_000,
    "Thor": 14_100,
    "Poseidon C3": 15_000,
    "UGM-73 Poseidon": 15_200,
    "Trident I (C4)": 15_400,
    "UGM-96 Trident I": 15_500,
    "UGM-133 Trident II": 20_000,
    "LGM-25C Titan II": 25_000,
    "Titan II": 30_000,

    # Tankers
    "Boeing KC-35 Stratotanker": 185_000,
    "Boeing KC-33 Pegasus": 195_000,
    "Airbus A330 MRTT": 200_000,
    "Ilyushin Il-73": 150_000,
    "Tupolev Tu-204 tanker": 130_000,

    # Naval
    "USS Gerald R. Ford Aircraft Carrier": 1_450_000,
    "Nimitz Aircraft Carrier": 1_350_000,
    "Admiral Kuznetsov Aircraft Carrier": 1_150_000,
    "Abraham Lincoln Aircraft Carrier": 1_220_000,
    "USS Arleigh Burke Fighter": 950_000,
    "Type 055 Destroyer Fighter": 980_000,
    "Kirov-class Battlecruiser Fighter": 1_100_000,
    "Scorpène-class Submarine Fighter": 780_000,
    "Kilo-class Submarine": 700_000,
    "Scorpène-class Submarine": 760_000,
    "Type 072 Submarine": 790_000,
    "Los Angeles-class Submarine": 820_000,
    "Kilo-Delta Submarine": 850_000,
    "Soryu-class Submarine": 880_000,
    "Type 101 Submarine": 940_000,

    # Troop transports
    "Laguna-class Transport": 600_000,
    "Normandy-class Transport": 630_000,
    "Whitby-class Transport": 660_000,
    "Kangaroo-class Transport": 690_000,
    "Wagner-class Transport": 750_000,
    "Warrior-class Transport": 810_000,
    "Warrekk-class Transport": 870_000,

    # Bomber bombs
    "Mk 82 — 500 lb": 8_000,
    "Paveway — 250 lb": 10_000,
    "Mk 84 — 2000 lb": 10_000,
    "GBU-39 SDB — 250 lb": 12_000,
    "GBU-54 — 500 lb": 16_000,
    "GBU-28 — 5000 lb": 18_000,
    "GBU-31 JDAM — 2000 lb": 18_000,

    # Human resources
    "1000 soldiers": 140_000,
    "1000 machine gunners": 210_000,
    "100 snipers": 350_000,
    "spy": 100_000,
    "hacker": 500_000,
    "police": 10_000,
    "bodyguard": 20_000,
    "hostage taker": 50_000,
    "bomber": 80_000,
    "bomb disposal": 150_000,
    "suicide attacker": 150_000,
    "1000 rioters": 200_000,
    "1000 anti-riot": 200_000,

    # Base: corrected to 10M and intentionally not 14M.
    "🏕️ پایگاه": 10_000_000,
}

# Advanced bombs are EXEMPT from the x7 multiplier.
ADVANCED_BOMBS = {
    "Antimatter Bomb": 30_000_000,
    "Hydrogen Bomb": 14_000_000,
    "H2 Bomb": 10_000_000,
    "Chemical Bomb": 4_000_000,
    # New Life is a special recovery item, not a normal destructive bomb.
    "new life": 500_000_000,
}

# Player buy price = 20% above the market sale price.
# For this fresh test build, the provided catalog values are treated as BUY prices.
# Therefore sale price = buy / 1.2.
def sale_price(buy_price):
    return buy_price / 1.20

def fmt(n):
    return f"{n:,.0f}"

def build_catalog():
    out = []
    for name, original in RAW_PRICES.items():
        buy = original
        out.append(("⛏️ منابع", name, buy, sale_price(buy)))
    for name, original in INGOT_PRICES.items():
        buy = original
        out.append(("⛏️ منابع", name, buy, sale_price(buy)))
    for name, original in WAR_EQUIPMENT_BASE.items():
        buy = original * WAR_MULTIPLIER
        # Base and human resources are nested under war equipment.
        out.append(("⚔️ تجهیزات جنگی", name, buy, sale_price(buy)))
    for name, original in ADVANCED_BOMBS.items():
        buy = original
        out.append(("💣 بمب‌های پیشرفته", name, buy, sale_price(buy)))
    return out

CATALOG = {name: {"category": cat, "buy": buy, "sell": sell}
           for cat, name, buy, sell in build_catalog()}

# ----------------------------
# Database
# ----------------------------
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS countries(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER UNIQUE,
        name TEXT NOT NULL,
        treasury REAL NOT NULL DEFAULT 1000000000,
        conquered INTEGER NOT NULL DEFAULT 0,
        alive INTEGER NOT NULL DEFAULT 1,
        recovery_used INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS inventory(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER,
        item TEXT,
        qty INTEGER NOT NULL DEFAULT 0,
        UNIQUE(telegram_id,item)
    );
    """)
    conn.commit()
    conn.close()

# ----------------------------
# Menus
# ----------------------------
MAIN = ReplyKeyboardMarkup(
    [["🌍 کشور من", "🏪 بازار"],
     ["🌐 تعاملات", "📢 بیانیه"],
     ["📜 قرارداد"]],
    resize_keyboard=True
)

def market_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🛒 خرید", callback_data="market_buy"),
         InlineKeyboardButton("💰 فروش", callback_data="market_sell")]
    ])

def category_menu(mode):
    rows = [
        [InlineKeyboardButton("⛏️ منابع", callback_data=f"cat:{mode}:resources")],
        [InlineKeyboardButton("🏭 شرکت‌ها", callback_data=f"cat:{mode}:companies")],
        [InlineKeyboardButton("⛏️ معادن", callback_data=f"cat:{mode}:mines")],
        [InlineKeyboardButton("🛢️ تجهیزات نفتی", callback_data=f"cat:{mode}:oil")],
        [InlineKeyboardButton("⚔️ تجهیزات جنگی", callback_data=f"cat:{mode}:war")],
    ]
    return InlineKeyboardMarkup(rows)

def war_menu(mode):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🌍 زمینی", callback_data=f"warcat:{mode}:ground")],
        [InlineKeyboardButton("✈️ هوایی", callback_data=f"warcat:{mode}:air")],
        [InlineKeyboardButton("🌊 دریایی", callback_data=f"warcat:{mode}:sea")],
        [InlineKeyboardButton("💣 بمب‌ها", callback_data=f"warcat:{mode}:bombs")],
        [InlineKeyboardButton("👥 نیروی انسانی", callback_data=f"warcat:{mode}:human")],
        [InlineKeyboardButton("🏕️ پایگاه", callback_data=f"warcat:{mode}:base")],
        [InlineKeyboardButton("🔬 بمب‌های پیشرفته", callback_data=f"warcat:{mode}:advanced")],
        [InlineKeyboardButton("🔙 برگشت", callback_data=f"backcat:{mode}")],
    ])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    init_db()
    conn = db()
    conn.execute("""
      INSERT OR IGNORE INTO countries(telegram_id,name)
      VALUES(?,?)
    """, (update.effective_user.id, f"کشور آزمایشی {update.effective_user.id}"))
    conn.commit()
    conn.close()
    await update.message.reply_text(
        "🧪 نسخه آزمایشی بازار\n\n"
        "این نسخه از صفر ساخته شده و فقط برای تست سیستم بازار/تجهیزات است.\n"
        "قیمت پایگاه = 10M و New Life بدون ×7 است.",
        reply_markup=MAIN
    )

def item_names(section):
    if section == "ground":
        names = list(WAR_EQUIPMENT_BASE)[:15]
    elif section == "air":
        names = list(WAR_EQUIPMENT_BASE)[15:15+19+11+13+5]
    elif section == "sea":
        start = 15+19+11+13+5
        names = list(WAR_EQUIPMENT_BASE)[start:start+15+7]
    elif section == "bombs":
        names = [n for n in WAR_EQUIPMENT_BASE if "lb" in n or "Paveway" in n or "JDAM" in n]
    elif section == "human":
        names = [n for n in WAR_EQUIPMENT_BASE if n in {
            "1000 soldiers","1000 machine gunners","100 snipers","spy","hacker","police",
            "bodyguard","hostage taker","bomber","bomb disposal","suicide attacker",
            "1000 rioters","1000 anti-riot"}]
    elif section == "base":
        names = ["🏕️ پایگاه"]
    elif section == "advanced":
        names = list(ADVANCED_BOMBS)
    else:
        names = []
    return [n for n in names if n in CATALOG]

async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data

    if data in ("market_buy", "market_sell"):
        mode = "buy" if data == "market_buy" else "sell"
        await q.edit_message_text(
            "🛒 خرید" if mode == "buy" else "💰 فروش",
            reply_markup=category_menu(mode)
        )
        return

    if data.startswith("cat:"):
        _, mode, section = data.split(":")
        if section == "war":
            await q.edit_message_text("⚔️ تجهیزات جنگی", reply_markup=war_menu(mode))
        else:
            await q.edit_message_text(
                "🧪 در این نسخه آزمایشی، جزئیات این بخش هنوز در حال تست است.\n"
                "برای تست کامل تغییرات خواسته‌شده، وارد تجهیزات جنگی شو.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("🔙 برگشت", callback_data=f"backcat:{mode}")]]
                )
            )
        return

    if data.startswith("backcat:"):
        mode = data.split(":")[1]
        await q.edit_message_text(
            "دسته را انتخاب کن:",
            reply_markup=category_menu(mode)
        )
        return

    if data.startswith("warcat:"):
        _, mode, section = data.split(":")
        names = item_names(section)
        buttons = []
        for name in names:
            p = CATALOG[name]["buy"] if mode == "buy" else CATALOG[name]["sell"]
            buttons.append([InlineKeyboardButton(
                f"{name} — {fmt(p)}",
                callback_data=f"item:{mode}:{name}"
            )])
        buttons.append([InlineKeyboardButton("🔙 تجهیزات جنگی", callback_data=f"cat:{mode}:war")])
        await q.edit_message_text(
            "انتخاب تجهیز:\nقیمت نمایش‌داده‌شده بر اساس حالت انتخابی است.",
            reply_markup=InlineKeyboardMarkup(buttons[:35])
        )
        return

    if data.startswith("item:"):
        _, mode, name = data.split(":", 2)
        item = CATALOG.get(name)
        if not item:
            await q.answer("آیتم پیدا نشد.", show_alert=True)
            return

        if name == "new life":
            extra = (
                "\n\n✨ قابلیت ویژه:\n"
                "اگر کشور کاملاً فتح شده باشد، New Life آن کشور را نجات می‌دهد "
                "و کشور را به وضعیت زنده برمی‌گرداند."
            )
        elif name == "🏕️ پایگاه":
            extra = "\n\n📍 قیمت پایگاه: 10,000,000 — بدون تبدیل به 14M."
        else:
            extra = ""

        price = item["buy"] if mode == "buy" else item["sell"]
        await q.edit_message_text(
            f"📦 {name}\n\n"
            f"{'💰 قیمت خرید' if mode == 'buy' else '💰 قیمت فروش'}: {fmt(price)}"
            f"{extra}\n\n"
            "برای این نسخه، خرید/فروش مالی واقعی هنوز اجرا نمی‌شود؛ "
            "هدف تست صحیح بودن کاتالوگ و قیمت‌هاست.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 برگشت", callback_data=f"warcat:{mode}:advanced"
                    if name in ADVANCED_BOMBS else f"warcat:{mode}:base"
                    if name == "🏕️ پایگاه" else f"cat:{mode}:war")]
            ])
        )
        return

async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.text == "🏪 بازار":
        await update.message.reply_text("🛒 بازار", reply_markup=market_menu())
    elif update.message.text == "🌍 کشور من":
        conn = db()
        c = conn.execute("SELECT * FROM countries WHERE telegram_id=?",
                         (update.effective_user.id,)).fetchone()
        conn.close()
        await update.message.reply_text(
            f"🌍 {c['name']}\n💰 خزانه: {fmt(c['treasury'])}\n"
            f"وضعیت: {'فعال' if c['alive'] else 'فتح‌شده'}",
            reply_markup=MAIN
        )
    else:
        await update.message.reply_text("از منوی اصلی انتخاب کن.", reply_markup=MAIN)

def recover_country(conn, telegram_id):
    row = conn.execute(
        "SELECT * FROM countries WHERE telegram_id=?", (telegram_id,)
    ).fetchone()
    if not row:
        return False, "کشور پیدا نشد."
    if not row["conquered"] and row["alive"]:
        return False, "کشور فتح نشده است."
    if row["recovery_used"]:
        return False, "New Life قبلاً برای این کشور مصرف شده است."
    conn.execute("""
        UPDATE countries
        SET conquered=0, alive=1, recovery_used=1
        WHERE telegram_id=?
    """, (telegram_id,))
    return True, "کشور با New Life نجات پیدا کرد و به زندگی برگشت."

def verify_prices():
    assert CATALOG["🏕️ پایگاه"]["buy"] == 10_000_000
    assert CATALOG["Antimatter Bomb"]["buy"] == 30_000_000
    assert CATALOG["Hydrogen Bomb"]["buy"] == 14_000_000
    assert CATALOG["H2 Bomb"]["buy"] == 10_000_000
    assert CATALOG["Chemical Bomb"]["buy"] == 4_000_000
    assert CATALOG["new life"]["buy"] == 500_000_000
    assert CATALOG["KF51 Tank"]["buy"] == 77_000
    assert CATALOG["F-22 Raptor"]["buy"] == 1_050_000
    return True

def main():
    verify_prices()
    init_db()
    token = os.getenv("BOT_TOKEN")
    if not token:
        raise SystemExit("BOT_TOKEN is required.")
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(callback))
    app.add_handler(__import__("telegram").ext.MessageHandler(
        __import__("telegram").ext.filters.TEXT & ~__import__("telegram").ext.filters.COMMAND,
        text_handler
    ))
    app.run_polling()

if __name__ == "__main__":
    main()
